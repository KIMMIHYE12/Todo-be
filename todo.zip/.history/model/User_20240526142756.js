const mongoose = requier("mongoose");
const Schema = mongoose.Schema;

const userSchema = Schema(
  {
    name: {
      type: String,
      requierd: true,
    },
    email: {
      type: String,
      requierd: true,
    },
    password: {
      type: String,
      requierd: true,
    },
  },
  { timestamps: true }
);

const User = mongoose.model("User", userSchema);
