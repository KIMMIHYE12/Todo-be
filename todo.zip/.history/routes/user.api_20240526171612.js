const express = require("express");
const userController = require("../controller/user.controller");
const router = express.Router();

router.post("/", userController.createUser);
router.post("/login",  async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ email });
    if (user) {
      const isMath = bcrypt.compare(password, user.password);
      if (isMath) {
        const token = user.generateToken();
        return res.status(200).json({ status: "success", user, token });
      }
    }
    throw new Error("아이디 또는 비밀번호가 일치하지 않습니다.");
  } catch (error) {
    res.status(400).json({ status: "fail", error });
  }
};);

module.exports = router;
