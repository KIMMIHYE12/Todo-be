const express = require("express");
const authController = require("../controller/auth.controller");
const taskController = require("../controller/task.controller");
const router = express.Router();

router.post("/", taskController.createTask);

router.get("/", authController.authenticate, taskController.getTask);

router.put("/:id", taskController.putTask);

router.delete("/:id", taskController.deleteTask);

module.exports = router;
