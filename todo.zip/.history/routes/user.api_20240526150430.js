const express = require("express");
const router = express.Router();
const userController = require("../controller/user.controller");

router.post("/", (req, res) => {
  res.send("create user controller will be hier");
});

module.exports = router;
