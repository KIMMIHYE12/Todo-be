const express = require("express");
const res = require("express/lib/response");
const router = express.Router();

router.post("/", (res, req) => {
  res.send("create user controller will be hier");
});
