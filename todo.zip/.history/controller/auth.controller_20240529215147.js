const authController = {};

authController.authenticate = () => {
  try {
    const tockenStirng = req.headers.authorization;
    const (!tockenStirng) = {
      throw new Error("invalid tocken")
    }
  } catch {}
};

module.exports = authController;
