const authController = {};
const res = require("express/lib/response");
const jwt = require("jasonwebtoken");
require("dotenv").config();
const JWT_SECRET_KEY = process.env.JWT_SECRET_KEY;

authController.authenticate = () => {
  try {
    const tockenStirng = req.headers.authorization;
    if (!tockenStirng) {
      throw new Error("invalid token");
    }
    const token = tockenStirng.replace("Bearer ", "");
    jwt.verify(token, JWT_SECRET_KEY, (error, payload) => {
      if (error) {
        throw new Error("invail token");
      }
      console.log("payload??", payload);
    });
  } catch (error) {
    res.status(400).json({ status: "fail", message: error.message });
  }
};

module.exports = authController;
