const User = require("../model/User");

const userController = {};

userController.createUser = async (req, res) => {
  try {
  } catch (error) {}
};

module.export = userController;
