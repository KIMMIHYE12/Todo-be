const userController = {};

userController.createUser = async (req, res) => {
  try {
    const { email, name, password } = req.body;
  } catch (error) {}
};

module.export = userController;
