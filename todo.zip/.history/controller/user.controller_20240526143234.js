const User = require("../model/User");

const userController = {};

userController.createUser = async (req, res) => {
  try {
    const { email, name, password } = req.body;
    const user = await User.findOne({ email: email });
  } catch (error) {}
};

module.export = userController;
