const authController = {};

authController.authenticate = () => {
  try {
    const tockenStirng = req.headers.authorization;
  } catch {}
};

module.exports = authController;
