const authController = {};

authController.authenticate = () => {
  try {
    const tockenStirng = req.headers.authorization;
    const (!tockenStirng) = {
      throw new Error("invalid token")
    }
  } catch {}
};

module.exports = authController;
