const authController = {};
const jwt require("jasonweboken")
authController.authenticate = () => {
  try {
    const tockenStirng = req.headers.authorization;
    const (!tockenStirng) = {
      throw new Error("invalid token")
    }
    const token =tockenStirng.replace("bearer", "")
  } catch {}
};

module.exports = authController;
