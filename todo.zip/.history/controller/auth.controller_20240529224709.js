const authController = {};
const jwt = require("jasonweboken");
require("dotenv").config();
const JWT_SECRET_KEY = process.env.JWT_SECRET_KEY;
authController.authenticate = () => {
  try {
    const tockenStirng = req.headers.authorization;
    if (!tockenStirng) {
      throw new Error("invalid token");
    }
    const token = tockenStirng.replace("Bearer", "");
    jwt.verify(token, JWT_SECRET_KEY, (error, payload) => {
      if (error) {
        throw new Error("invail token");
      }
      console.log("payload", payload);
    });
  } catch {}
};

module.exports = authController;
