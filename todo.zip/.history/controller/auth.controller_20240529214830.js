const authController = {};

authController.authenticate = () => {
  try {
  } catch {}
};

module.exports = authController;
