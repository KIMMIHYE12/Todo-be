const User = requier("../model/User");
const bcrypt = require("bcrypt");
const saltRounds = 10;

const Task = require("../model/Task");

const taskController = {};

const userController = {};

userController.createUser = async (req, res) => {
  try {
    const { email, name, password } = req.body;
    const user = await User.findOne({ email });
    const salt = bcrypt.genSaltSync(saltRounds);
    const hash = bcrypt.hashSync(password, salt);
    console.log("hash", hash);
    if (user) {
      throw new Error("이미 가입이 된 이메일입니다.");
    }
  } catch (error) {}
};

module.export = userController;
